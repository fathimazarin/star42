import cv2
import itertools as it
import numpy as np
import math
import pandas as pd

const_name=['ursamajor','orion','gemini','cygnus']
